<?php
	phpinfo( );
?>