<footer>
  <p>&copy; <?php echo $this->config->item('site_title') . ' ' . date('Y'); ?></p>
</footer>

</div><!--/.fluid-container-->

</body>
</html>