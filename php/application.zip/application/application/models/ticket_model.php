<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');

/**
 * Copyright (c) 2015, Studio76.PRO - FunnyPappers - https://www.studio76.pro 
 */
class Ticket_model extends MY_Model
{
  public function __construct()
  {
    parent::__construct();
    $this->table_name = 'ticket';
  }
  
  /**
   * Get ticket by uuid.
   * 
   * @param type $uuid
   * @return type 
   */
  public function get_by_uuid($uuid)
  {
    $q = $this->db->get_where($this->table_name, array('uuid' => $uuid));
    
    return $q->row();
  }

}