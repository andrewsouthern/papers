<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');

/**
 * Copyright (c) 2015, Studio76.PRO - FunnyPappers - https://www.studio76.pro 
 */
class Config_model extends MY_Model
{
  public function __construct()
  {
    parent::__construct();
    $this->table_name = 'album_config';
  }
  
  /**
   * Get config by album id.
   * 
   * @param type $album_id
   * @return type 
   */
  public function get_by_album_id($album_id)
  {
    $this->db->select('*')
             ->from($this->table_name)
             ->where('album_id', $album_id);
    $q = $this->db->get();
    
    return $q->row();
  }
  
  /**
   * Update config by album id.
   * 
   * @param array $data
   * @param type $album_id
   * @return type 
   */
  public function update_by_album_id(array $data, $album_id)
  {
    $this->db->update($this->table_name, $data, array('album_id' => $album_id));
    
    return $album_id;
  }
  
  /**
   * Delete config by album id.
   * 
   * @param type $album_id
   * @return type 
   */
  public function delete_by_album_id($album_id)
  {
    $this->db->delete($this->table_name, array('album_id' => $album_id));
    
    return $album_id;
  }
}
